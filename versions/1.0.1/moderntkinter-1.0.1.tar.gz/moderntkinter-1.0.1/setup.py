from setuptools import setup, find_packages

setup(
    name="moderntkinter",
    version="1.0.1",
    packages=find_packages(where="moderntkinter"),
    install_requires=[],
    description="ModernTkinter (MTK) - A modern version of CustomTkinter",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author="TheWhiteCreator",
    url="https://github.com/NotVirusTotal/moderntkinter",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
